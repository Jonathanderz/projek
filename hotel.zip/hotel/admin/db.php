<?php
$con = mysqli_connect("localhost","jonathan_hotel","jonathan_hotel","jonathan_hotel") or die(mysql_error());

?>